import MovieCard from "../components/MovieCard";

function WorkShop (){
    return (
        <div>
            <h2>WorkShop</h2>
            <MovieCard/>
        </div>
    );
}

export default WorkShop;